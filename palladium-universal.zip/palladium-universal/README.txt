Palladium Universal Foundry Starter
==================================

Included:
- system.json
- module/system.js
- templates/actor/actor-sheet.hbs
- styles/actor-sheet.css
- lang/en.json

What this does:
- Modern tabbed actor sheet
- Collapsible sections
- Derived stat display for basic PP/PE/PS/IQ bonuses
- Optional modules for MDC, Magic, Psionics, Mutations, Super Powers, Mecha, Survival/Horror

What you will likely want to do next:
1. Add Item support for skills, weapons, armor, and powers.
2. Expand the derived stat formulas to match your preferred Palladium line exactly.
3. Add roll buttons for strikes, saves, skills, and damage.
4. Create separate NPC and vehicle actor types if desired.

Install:
Copy this folder into FoundryVTT/Data/systems/palladium-universal/
Then launch Foundry and enable the system for a world.
