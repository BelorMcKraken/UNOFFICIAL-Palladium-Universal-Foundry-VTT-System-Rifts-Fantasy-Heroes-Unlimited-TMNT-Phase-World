class PalladiumUniversalActorSheet extends foundry.appv1.sheets.ActorSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["palladium-universal", "sheet", "actor", "character"],
      template: "systems/palladium-universal/templates/actor/actor-sheet.hbs",
      width: 980,
      height: 860,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "core" }]
    });
  }

  getData() {
    const data = super.getData();

    const defaults = {
      identity: {
        alignment: "",
        level: "",
        xp: "",
        classType: "",
        species: "",
        campaign: ""
      },

      attributes: {
        iq: { value: "" },
        me: { value: "" },
        ma: { value: "" },
        ps: { value: "" },
        pp: { value: "" },
        pe: { value: "" },
        pb: { value: "" },
        spd: { value: "" }
      },

      derived: {
        iqSkillBonus: "",
        ppCombatBonus: "",
        peHpBonus: "",
        psDamageBonus: "",
        suggestedInitiative: "",
        suggestedStrike: "",
        suggestedParry: "",
        suggestedDodge: ""
      },

      health: {
        hp: { value: "", max: "" },
        sdc: { value: "", max: "" },
        mdc: { value: "", max: "" },
        armor: "",
        armorCapacity: { value: "", max: "" },
        forceField: { value: "", max: "" }
      },

      combat: {
        initiative: "",
        attacksPerMelee: "",
        strike: "",
        parry: "",
        dodge: "",
        damageBonus: "",
        disarm: "",
        pullPunch: "",
        rollImpact: "",
        critical: "",
        koStun: ""
      },

      saves: {
        magic: "",
        psionics: "",
        poison: "",
        horror: ""
      },

      skills: "",
      gear: "",

      toggles: {
        useMdc: false,
        useMagic: false,
        usePsionics: false,
        useMutations: false,
        useSuperPowers: false,
        useMecha: false,
        useSurvivalHorror: false
      },

      magic: {
        ppe: { value: "", max: "" },
        spellStrength: "",
        spells: ""
      },

      psionics: {
        isp: { value: "", max: "" },
        powers: ""
      },

      mutations: {
        animalType: "",
        bioeTotal: "",
        bioeSpent: "",
        sizeLevel: "",
        mutations: ""
      },

      superPowers: {
        category: "",
        powers: "",
        weaknesses: ""
      },

      mecha: {
        name: "",
        mdcByLocation: "",
        weaponSystems: "",
        speed: "",
        handling: ""
      },

      survival: {
        infectionLevel: "",
        supplies: "",
        insanityEffects: ""
      },

      notes: ""
    };

    data.system = foundry.utils.mergeObject(
      foundry.utils.deepClone(defaults),
      this.actor.system ?? {},
      { inplace: false }
    );

    this._prepareDerivedData(data.system);

    data.tokenImage =
      this.actor.prototypeToken?.texture?.src ||
      this.actor.img ||
      "icons/svg/mystery-man.svg";

    return data;
  }

  _prepareDerivedData(system) {
    const a = system.attributes ?? {};
    const d = system.derived ?? {};

    const iqRaw = a.iq?.value;
    const ppRaw = a.pp?.value;
    const peRaw = a.pe?.value;
    const psRaw = a.ps?.value;

    const iq = iqRaw === "" || iqRaw === null || iqRaw === undefined ? null : Number(iqRaw);
    const pp = ppRaw === "" || ppRaw === null || ppRaw === undefined ? null : Number(ppRaw);
    const pe = peRaw === "" || peRaw === null || peRaw === undefined ? null : Number(peRaw);
    const ps = psRaw === "" || psRaw === null || psRaw === undefined ? null : Number(psRaw);

    d.iqSkillBonus = iq === null || Number.isNaN(iq) ? "" : this._calcIqSkillBonus(iq);
    d.ppCombatBonus = pp === null || Number.isNaN(pp) ? "" : this._calcPpCombatBonus(pp);
    d.peHpBonus = pe === null || Number.isNaN(pe) ? "" : this._calcPeHpBonus(pe);
    d.psDamageBonus = ps === null || Number.isNaN(ps) ? "" : this._calcPsDamageBonus(ps);

    // Suggestions only. These do NOT overwrite manual combat fields.
    d.suggestedInitiative = d.ppCombatBonus;
    d.suggestedStrike = d.ppCombatBonus;
    d.suggestedParry = d.ppCombatBonus;
    d.suggestedDodge = d.ppCombatBonus;
  }

  _calcIqSkillBonus(iq) {
    if (iq >= 24) return 20;
    if (iq >= 22) return 15;
    if (iq >= 20) return 10;
    if (iq >= 18) return 8;
    if (iq >= 16) return 5;
    return 0;
  }

  _calcPpCombatBonus(pp) {
    if (pp >= 30) return 8;
    if (pp >= 26) return 7;
    if (pp >= 24) return 6;
    if (pp >= 22) return 5;
    if (pp >= 20) return 4;
    if (pp >= 18) return 3;
    if (pp >= 16) return 2;
    return 0;
  }

  _calcPeHpBonus(pe) {
    if (pe >= 30) return 30;
    if (pe >= 26) return 24;
    if (pe >= 24) return 20;
    if (pe >= 22) return 16;
    if (pe >= 20) return 12;
    if (pe >= 18) return 8;
    if (pe >= 16) return 4;
    return 0;
  }

  _calcPsDamageBonus(ps) {
    if (ps >= 30) return 10;
    if (ps >= 26) return 8;
    if (ps >= 24) return 6;
    if (ps >= 22) return 5;
    if (ps >= 20) return 4;
    if (ps >= 18) return 3;
    if (ps >= 16) return 2;
    return 0;
  }

  activateListeners(html) {
    super.activateListeners(html);

    html.find(".collapse-toggle").on("click", (ev) => {
      const target = ev.currentTarget.dataset.target;
      html.find(`[data-collapse='${target}']`).toggleClass("collapsed");
    });
  }
}

Hooks.once("init", async function () {
  console.log("Palladium Universal | Initializing system");

  foundry.documents.collections.Actors.unregisterSheet(
    "core",
    foundry.appv1.sheets.ActorSheet
  );

  foundry.documents.collections.Actors.registerSheet(
    "palladium-universal",
    PalladiumUniversalActorSheet,
    {
      types: ["character"],
      makeDefault: true,
      label: "Palladium Universal Sheet"
    }
  );
});